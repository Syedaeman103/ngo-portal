<?php
$lang = [
    "title" => "यूज़र डैशबोर्ड",
    "view_events" => "इवेंट देखें",
    "join_events" => "इवेंट जॉइन करें",
    "logout" => "लॉगआउट",
    "available_events" => "उपलब्ध इवेंट",
    "join_event" => "इवेंट जॉइन करें",
    "date" => "तारीख",
    "no_events" => "कोई इवेंट नहीं मिला"
];
?>