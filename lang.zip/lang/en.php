<?php
$lang = [
    "title" => "User Dashboard",
    "view_events" => "View Events",
    "join_events" => "Join Events",
    "logout" => "Logout",
    "available_events" => "Available Events",
    "join_event" => "Join Event",
    "date" => "Date",
    "no_events" => "No events found"
];
?>