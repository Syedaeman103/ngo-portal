// You can add JS functionality later (optional)
console.log("NGO Portal Loaded");
body {
    background: url('https://images.unsplash.com/photo-1501004318641-b39e6451bec6') no-repeat center center/cover;
}
